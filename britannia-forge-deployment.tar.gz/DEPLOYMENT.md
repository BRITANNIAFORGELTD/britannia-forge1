# Deployment Guide - Britannia Forge Platform

## Prerequisites

### System Requirements
- Node.js 18+ 
- PostgreSQL 14+
- Git
- Domain name (britanniaforge.co.uk)

### Required Services
- **Neon Database** (or PostgreSQL hosting)
- **Stripe Account** (for payment processing)
- **Email Service** (SendGrid/SMTP)
- **SSL Certificate** (for HTTPS)

## Environment Setup

1. **Create Environment File**
   ```bash
   cp .env.example .env
   ```

2. **Configure Database**
   ```env
   DATABASE_URL=postgresql://user:pass@host:5432/db_name
   ```

3. **Set up Stripe**
   - Create Stripe account
   - Get API keys from Stripe Dashboard
   - Add to .env file

4. **Configure Email**
   - Set up SendGrid or SMTP service
   - Add credentials to .env

## Database Setup

1. **Initialize Database**
   ```bash
   npm run db:push
   ```

2. **Create Admin Account**
   ```bash
   npm run create-admin
   ```

3. **Verify Tables**
   - users
   - quotes
   - jobs
   - boilers
   - labour_costs
   - sundries
   - contact_messages

## Production Deployment

### Method 1: Traditional Server

1. **Build Application**
   ```bash
   npm run build
   ```

2. **Start Production Server**
   ```bash
   npm start
   ```

3. **Set up Process Manager**
   ```bash
   # Using PM2
   npm install -g pm2
   pm2 start dist/index.js --name britannia-forge
   pm2 save
   pm2 startup
   ```

### Method 2: Docker (Recommended)

1. **Create Dockerfile**
   ```dockerfile
   FROM node:18-alpine
   
   WORKDIR /app
   COPY package*.json ./
   RUN npm ci --only=production
   
   COPY . .
   RUN npm run build
   
   EXPOSE 5000
   CMD ["npm", "start"]
   ```

2. **Build and Run**
   ```bash
   docker build -t britannia-forge .
   docker run -p 5000:5000 --env-file .env britannia-forge
   ```

### Method 3: Vercel/Netlify (Serverless)

1. **Configure Build Settings**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Node Version: 18.x

2. **Set Environment Variables**
   - Add all .env variables to platform settings

## SSL and Domain Setup

1. **Configure DNS**
   - Point domain to server IP
   - Set up www subdomain

2. **SSL Certificate**
   ```bash
   # Using Let's Encrypt
   certbot --nginx -d britanniaforge.co.uk -d www.britanniaforge.co.uk
   ```

3. **Nginx Configuration**
   ```nginx
   server {
     listen 443 ssl;
     server_name britanniaforge.co.uk www.britanniaforge.co.uk;
     
     ssl_certificate /path/to/cert.pem;
     ssl_certificate_key /path/to/private.key;
     
     location / {
       proxy_pass http://localhost:5000;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
     }
   }
   ```

## Security Checklist

- [ ] Change default JWT secret
- [ ] Use HTTPS for all requests
- [ ] Set up CORS properly
- [ ] Enable rate limiting
- [ ] Configure firewall
- [ ] Set up monitoring
- [ ] Regular security updates
- [ ] Database backups
- [ ] Log rotation

## Monitoring and Maintenance

### Health Checks
- Database connectivity
- API response times
- Payment processing
- Email delivery
- Storage usage

### Backup Strategy
- Daily database backups
- Weekly full system backups
- Test restore procedures
- Monitor backup integrity

### Performance Monitoring
- Server resources (CPU, Memory)
- Database performance
- API response times
- User activity metrics

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   ```bash
   # Check database URL format
   # Verify firewall settings
   # Test connection manually
   ```

2. **Stripe Payment Failures**
   ```bash
   # Verify API keys
   # Check webhook endpoints
   # Review Stripe logs
   ```

3. **Email Delivery Issues**
   ```bash
   # Check SMTP settings
   # Verify DNS records
   # Test email service
   ```

## Scaling Considerations

### Load Balancing
- Multiple server instances
- Database read replicas
- CDN for static assets
- Redis for session storage

### Database Optimization
- Connection pooling
- Query optimization
- Indexing strategy
- Monitoring slow queries

## Support and Updates

### Regular Tasks
- Security updates
- Dependency updates
- Performance monitoring
- Backup verification

### Emergency Procedures
- Rollback procedures
- Database recovery
- Service restoration
- Communication plan

## Contact Information

For deployment support:
- Technical Lead: britanniaforge@gmail.com
- Repository: https://github.com/BRITANNIAFORGELTD/britannia-forge-website
- Documentation: See README.md

---

**Note**: This deployment guide assumes production environment setup. For development, use `npm run dev` instead.