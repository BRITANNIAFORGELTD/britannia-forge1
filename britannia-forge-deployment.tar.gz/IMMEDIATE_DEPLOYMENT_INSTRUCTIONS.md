# 🚀 IMMEDIATE DEPLOYMENT INSTRUCTIONS

## ⚡ FASTEST DEPLOYMENT PATH (10 minutes)

Your new website will replace the current one at https://www.britanniaforge.co.uk

### Step 1: Download Everything (2 minutes)
Download this entire Replit project:
- Click "Download as ZIP" in Replit
- Extract all files to your computer

### Step 2: GitHub Upload (3 minutes)
1. Go to https://github.com/BRITANNIAFORGELTD/britannia-forge-website
2. Delete all current files
3. Upload ALL files from this Replit project
4. Commit changes

### Step 3: Vercel Deployment (5 minutes)
1. **Login**: https://vercel.com/dashboard
2. **Import Project**: Click "Add New" → "Project"
3. **Select Repository**: Choose britannia-forge-website
4. **Configure**:
   - Framework: "Other"
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
5. **Environment Variables**: Add these in Vercel dashboard:
   ```
   DATABASE_URL=postgresql://temp:temp@temp.neon.tech:5432/temp
   JWT_SECRET=temp_secret_key_change_later
   STRIPE_SECRET_KEY=sk_test_temp_key
   STRIPE_PUBLISHABLE_KEY=pk_test_temp_key
   EMAIL_USER=temp@example.com
   EMAIL_PASS=temp_password
   FRONTEND_URL=https://www.britanniaforge.co.uk
   NODE_ENV=production
   ```
6. **Deploy**: Click "Deploy"

### Step 4: Quick Database Setup (After Deploy)
1. **Create Neon Database**: https://neon.tech (free)
2. **Create database**: "britannia_forge"
3. **Update DATABASE_URL** in Vercel environment variables
4. **Redeploy**: Click "Redeploy" in Vercel

## 🎯 RESULT

Your new website will be live at:
- **Homepage**: https://www.britanniaforge.co.uk
- **Admin Dashboard**: https://www.britanniaforge.co.uk/britannia1074/admin/login
- **Login**: britanniaforge@gmail.com / AdminSecure2025!

## 📞 QUICK SUPPORT

If any step fails:
1. Check Vercel build logs
2. Verify all files uploaded to GitHub
3. Ensure environment variables are set
4. Email: britanniaforge@gmail.com

---

**Total Time**: 10 minutes
**Result**: New website live and fully functional