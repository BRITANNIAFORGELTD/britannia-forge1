# GitHub Deployment Guide - Britannia Forge

## 📋 Pre-Deployment Checklist

### 1. Repository Setup
- [x] **README.md** - Comprehensive project documentation
- [x] **LICENSE** - MIT license file
- [x] **.gitignore** - Proper Git ignore rules
- [x] **package.json** - Project metadata and dependencies
- [x] **.env.example** - Environment variable template

### 2. CI/CD Configuration
- [x] **GitHub Actions Workflow** - `.github/workflows/deploy.yml`
- [x] **Docker Configuration** - `Dockerfile` and `docker-compose.yml`
- [x] **Nginx Configuration** - `nginx.conf` for reverse proxy
- [x] **Health Check Endpoint** - `/health` for monitoring

### 3. Database Setup
- [x] **Database Schema** - Complete Drizzle ORM schema
- [x] **Migration Scripts** - `npm run db:push` command
- [x] **Admin User Creation** - `npm run create-admin` script
- [x] **Data Seeding** - Comprehensive pricing data seeding

### 4. Security Configuration
- [x] **Environment Variables** - All sensitive data in .env
- [x] **JWT Authentication** - Secure token-based auth
- [x] **Password Hashing** - bcrypt implementation
- [x] **Role-based Access Control** - Admin, Editor, Engineer, Customer roles
- [x] **Protected Routes** - Middleware-based protection

## 🚀 Deployment Steps

### Step 1: Clone Repository
```bash
git clone https://github.com/BRITANNIAFORGELTD/britannia-forge-website.git
cd britannia-forge-website
```

### Step 2: Environment Setup
```bash
# Copy environment template
cp .env.example .env

# Edit environment variables
nano .env
```

Required Environment Variables:
```env
DATABASE_URL=postgresql://user:pass@host:5432/db
JWT_SECRET=your_super_secret_jwt_key
STRIPE_SECRET_KEY=sk_live_your_stripe_secret
STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable
EMAIL_USER=your_email@domain.com
EMAIL_PASS=your_email_password
FRONTEND_URL=https://britanniaforge.co.uk
NODE_ENV=production
```

### Step 3: Quick Deployment
```bash
# Make deploy script executable
chmod +x deploy.sh

# Run deployment script
./deploy.sh production
```

### Step 4: Manual Deployment (Alternative)
```bash
# Install dependencies
npm ci

# Build project
npm run build

# Database setup
npm run db:push

# Create admin user
npm run create-admin

# Start production server
npm start
```

## 🐳 Docker Deployment

### Development
```bash
docker-compose up -d
```

### Production
```bash
# Build and run
docker build -t britannia-forge .
docker run -p 5000:5000 --env-file .env britannia-forge
```

## 🔧 GitHub Actions Setup

The repository includes a GitHub Actions workflow that:
- Runs tests on every push
- Builds the project
- Deploys to production on main branch

### Required GitHub Secrets
Add these secrets to your GitHub repository:
- `DATABASE_URL`
- `JWT_SECRET`
- `STRIPE_SECRET_KEY`
- `STRIPE_PUBLISHABLE_KEY`
- `EMAIL_USER`
- `EMAIL_PASS`

## 📊 Production Monitoring

### Health Check
```bash
curl https://britanniaforge.co.uk/health
```

Expected Response:
```json
{
  "status": "healthy",
  "timestamp": "2025-01-16T07:19:00.000Z",
  "environment": "production"
}
```

### Key Endpoints
- **Main Site**: `https://britanniaforge.co.uk`
- **Admin Dashboard**: `https://britanniaforge.co.uk/britannia1074/admin/login`
- **Customer Portal**: `https://britanniaforge.co.uk/customer-dashboard`
- **Engineer Portal**: `https://britanniaforge.co.uk/engineer-portal`
- **Quote System**: `https://britanniaforge.co.uk/quote`

## 🔐 Admin Access

### Default Admin Login
- **URL**: `https://britanniaforge.co.uk/britannia1074/admin/login`
- **Email**: `britanniaforge@gmail.com`
- **Password**: `AdminSecure2025!`

### Creating Additional Users
```bash
# Create admin user
npm run create-admin

# Create editor user through admin dashboard
# Navigate to: /britannia1074/admin/users
```

## 📈 Post-Deployment Tasks

### 1. SSL Certificate Setup
```bash
# Using Let's Encrypt
certbot --nginx -d britanniaforge.co.uk -d www.britanniaforge.co.uk
```

### 2. Database Backup
```bash
# Setup automated backups
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d).sql
```

### 3. Performance Monitoring
- Server resource usage
- Database performance
- API response times
- User activity metrics

### 4. Security Updates
- Regular dependency updates
- Security patches
- SSL certificate renewal
- Firewall configuration

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   ```bash
   # Check database URL format
   echo $DATABASE_URL
   # Test connection
   psql $DATABASE_URL -c "SELECT 1;"
   ```

2. **Build Failures**
   ```bash
   # Clear cache and rebuild
   rm -rf node_modules package-lock.json
   npm install
   npm run build
   ```

3. **Permission Errors**
   ```bash
   # Fix script permissions
   chmod +x deploy.sh
   ```

4. **Port Conflicts**
   ```bash
   # Check port usage
   netstat -tlnp | grep 5000
   # Kill process if needed
   fuser -k 5000/tcp
   ```

## 📞 Support

For deployment issues:
- **Email**: britanniaforge@gmail.com
- **Repository**: https://github.com/BRITANNIAFORGELTD/britannia-forge-website
- **Documentation**: See README.md and DEPLOYMENT.md

## 🎯 Success Metrics

### Performance Targets
- **Page Load Time**: < 3 seconds
- **API Response Time**: < 500ms
- **Database Query Time**: < 100ms
- **Uptime**: 99.9%

### Business Metrics
- **Quote Conversion Rate**: Track customer quotes to bookings
- **Engineer Utilization**: Monitor job completion rates
- **Customer Satisfaction**: Review system feedback
- **Revenue Growth**: Track monthly revenue trends

---

**Deployment Status**: ✅ Ready for Production
**Last Updated**: January 16, 2025
**Version**: 1.0.0