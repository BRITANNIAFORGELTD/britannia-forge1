// Test Script for 25 Boiler Installation Scenarios
// Using Enhanced Intelligent Quote Engine with London Labor Rates

const scenarios = [
  {
    id: 1,
    name: "Standard Combi Swap",
    property: {
      bedrooms: "2",
      bathrooms: "1", 
      occupants: "2",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 2,
    name: "Small Flat with Vertical Flue",
    property: {
      bedrooms: "1",
      bathrooms: "1",
      occupants: "1", 
      propertyType: "Flat",
      currentBoiler: "Combi",
      flueLocation: "Through Roof",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 3,
    name: "Back Boiler Nightmare",
    property: {
      bedrooms: "3",
      bathrooms: "1",
      occupants: "4",
      propertyType: "House", 
      currentBoiler: "Regular",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "Yes",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 4,
    name: "System Boiler Upgrade",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "4",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall", 
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 5,
    name: "Awkward Flue Extension",
    property: {
      bedrooms: "3",
      bathrooms: "1",
      occupants: "3",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes", 
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 6,
    name: "Large Family Home",
    property: {
      bedrooms: "5",
      bathrooms: "3",
      occupants: "6",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 7,
    name: "Landlord's Budget Install",
    property: {
      bedrooms: "1",
      bathrooms: "1",
      occupants: "2",
      propertyType: "Flat",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 8,
    name: "Loft Installation",
    property: {
      bedrooms: "3",
      bathrooms: "1", 
      occupants: "2",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "Through Roof",
      drainNearby: "No",
      moveBoiler: "Yes",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 9,
    name: "LPG Property",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "4",
      propertyType: "House",
      currentBoiler: "Regular",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 10,
    name: "Power Flush Requirement",
    property: {
      bedrooms: "3",
      bathrooms: "1",
      occupants: "3",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 11,
    name: "Boiler Relocation",
    property: {
      bedrooms: "2",
      bathrooms: "1",
      occupants: "2",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "Yes",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 12,
    name: "High-End Smart Home",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "2",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 13,
    name: "Conventional-to-System Swap",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "5",
      propertyType: "House",
      currentBoiler: "Regular",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 14,
    name: "Jacuzzi Bath Challenge",
    property: {
      bedrooms: "3",
      bathrooms: "2",
      occupants: "2",
      propertyType: "Flat",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 15,
    name: "Townhouse Vertical Challenge",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "4",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 16,
    name: "Underfloor Heating Integration",
    property: {
      bedrooms: "2",
      bathrooms: "1",
      occupants: "2",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 17,
    name: "Massive House (Cascade System)",
    property: {
      bedrooms: "5+",
      bathrooms: "4+",
      occupants: "5+",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 18,
    name: "Listed Building",
    property: {
      bedrooms: "3",
      bathrooms: "1",
      occupants: "2",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 19,
    name: "Combi-to-System Conversion",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "4",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 20,
    name: "Simple System Boiler Swap",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "3",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 21,
    name: "Microbore Pipework Problem",
    property: {
      bedrooms: "3",
      bathrooms: "1",
      occupants: "3",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 22,
    name: "Conservatory Heat Loss",
    property: {
      bedrooms: "3",
      bathrooms: "1",
      occupants: "2",
      propertyType: "House",
      currentBoiler: "Combi",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 23,
    name: "High-Pressure Mains Challenge",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "5",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 24,
    name: "Solar Thermal Integration",
    property: {
      bedrooms: "4",
      bathrooms: "2",
      occupants: "4",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  },
  {
    id: 25,
    name: "Do It All Premium Job",
    property: {
      bedrooms: "5",
      bathrooms: "3",
      occupants: "5",
      propertyType: "House",
      currentBoiler: "System",
      flueLocation: "External Wall",
      drainNearby: "Yes",
      moveBoiler: "No",
      postcode: "SW1A 1AA"
    }
  }
];

// Export for testing
module.exports = { scenarios };