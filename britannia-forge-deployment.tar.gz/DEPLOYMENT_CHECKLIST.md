# 🚀 DEPLOYMENT CHECKLIST - britanniaforge.co.uk

## ✅ IMMEDIATE DEPLOYMENT STATUS

**Domain**: britanniaforge.co.uk  
**Current Hosting**: Vercel (ns1.vercel-dns.com, ns2.vercel-dns.com)  
**Deployment Method**: Direct Vercel deployment (will replace current site)  
**Estimated Time**: 5-10 minutes  

## 📋 PRE-DEPLOYMENT VERIFICATION

### ✅ Code Ready
- [x] Complete React frontend with TypeScript
- [x] Express.js backend with all APIs
- [x] Database schema with Drizzle ORM
- [x] Authentication system (JWT + bcrypt)
- [x] Payment integration (Stripe)
- [x] Admin dashboard at `/britannia1074/admin/login`
- [x] Vercel configuration (`vercel.json`)
- [x] Environment variables template

### ✅ Database Setup
- [x] PostgreSQL schema defined
- [x] Migration scripts ready (`npm run db:push`)
- [x] Admin user creation script
- [x] Test data seeding scripts

### ✅ Security Features
- [x] Role-based access control
- [x] Protected API endpoints
- [x] Password hashing (bcrypt)
- [x] JWT token authentication
- [x] Email verification system

## 🎯 DEPLOYMENT STEPS

### Step 1: GitHub Repository Upload
You need to upload these files to your GitHub repository:
**Repository**: https://github.com/BRITANNIAFORGELTD/britannia-forge-website

**Critical Files to Upload**:
```
├── server/                 # Complete backend
├── client/                 # Complete frontend
├── shared/                 # Database schema
├── vercel.json            # Vercel configuration
├── package.json           # Dependencies
├── .env.example           # Environment template
├── README.md              # Documentation
├── DEPLOYMENT.md          # Deployment guide
└── All other project files
```

### Step 2: Vercel Dashboard Configuration
1. **Login**: https://vercel.com/dashboard
2. **Import Project**: Connect GitHub repository
3. **Configure Build**:
   - Framework: "Other"
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

### Step 3: Environment Variables Setup
In Vercel Dashboard → Settings → Environment Variables:

```env
DATABASE_URL=postgresql://username:password@host:5432/britannia_forge
JWT_SECRET=your_super_secret_jwt_key_here
STRIPE_SECRET_KEY=sk_live_your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable_key
EMAIL_USER=your_email@domain.com
EMAIL_PASS=your_email_password
FRONTEND_URL=https://www.britanniaforge.co.uk
NODE_ENV=production
```

### Step 4: Database Setup (After Deployment)
```bash
# Create database (use Neon Database for Vercel)
# 1. Go to https://neon.tech
# 2. Create database: "britannia_forge"
# 3. Copy connection string to DATABASE_URL

# Run migrations
npx drizzle-kit push

# Create admin user
npx tsx server/create-admin.ts
```

### Step 5: Deploy & Test
1. **Deploy**: Click deploy in Vercel dashboard
2. **Monitor**: Watch build logs for errors
3. **Test**: Verify all endpoints work
4. **Go Live**: Your new site will be live at https://www.britanniaforge.co.uk

## 🔧 RECOMMENDED DATABASE SETUP

### Neon Database (Recommended for Vercel)
1. **Create Account**: https://neon.tech
2. **New Project**: "britannia-forge"
3. **Copy Connection String**: 
   ```
   postgresql://username:password@host.neon.tech:5432/britannia_forge
   ```
4. **Set in Vercel**: Environment Variables → DATABASE_URL

### Alternative: Supabase
1. **Create Account**: https://supabase.com
2. **New Project**: "britannia-forge"
3. **Get Connection String** from Settings → Database
4. **Set in Vercel**: Environment Variables → DATABASE_URL

## 📊 POST-DEPLOYMENT TESTING

### Critical Tests
- [ ] **Homepage**: https://www.britanniaforge.co.uk
- [ ] **Quote System**: https://www.britanniaforge.co.uk/quote
- [ ] **Admin Login**: https://www.britanniaforge.co.uk/britannia1074/admin/login
- [ ] **Health Check**: https://www.britanniaforge.co.uk/health
- [ ] **Payment Flow**: Test Stripe integration
- [ ] **User Registration**: Test customer signup
- [ ] **Database**: Verify all data operations

### Admin Login Test
```bash
curl -X POST https://www.britanniaforge.co.uk/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"britanniaforge@gmail.com","password":"AdminSecure2025!"}'
```

## 🚨 TROUBLESHOOTING

### Common Issues & Solutions

1. **Build Fails**
   - Check build logs in Vercel dashboard
   - Verify all dependencies are installed
   - Ensure TypeScript compilation succeeds

2. **Database Connection Error**
   - Verify DATABASE_URL format
   - Check database is accessible from Vercel
   - Ensure connection string includes SSL parameters

3. **Environment Variables**
   - All variables must be set in Vercel dashboard
   - Check spelling and formatting
   - Restart deployment after changes

4. **Function Timeout**
   - Increase maxDuration in vercel.json
   - Optimize database queries
   - Check for infinite loops

## 🎉 SUCCESS CONFIRMATION

### Your New Website Will Have:
- ✅ **Intelligent Boiler Quotation System**
- ✅ **Customer Portal** with job tracking
- ✅ **Admin Dashboard** with full control
- ✅ **Engineer Portal** for trade professionals
- ✅ **Secure Payment Processing** with Stripe
- ✅ **Role-Based Access Control**
- ✅ **Email Verification System**
- ✅ **Mobile-Responsive Design**
- ✅ **Professional UK Market Pricing**

### Admin Access After Deployment:
- **URL**: https://www.britanniaforge.co.uk/britannia1074/admin/login
- **Email**: britanniaforge@gmail.com
- **Password**: AdminSecure2025!

## 📞 SUPPORT

### If You Need Help:
- **Email**: britanniaforge@gmail.com
- **GitHub**: https://github.com/BRITANNIAFORGELTD/britannia-forge-website
- **Vercel Support**: https://vercel.com/support

### Emergency Contact:
If deployment fails, check:
1. Vercel build logs
2. Environment variables
3. Database connection
4. GitHub repository sync

---

**STATUS**: ✅ READY FOR IMMEDIATE DEPLOYMENT  
**NEXT STEP**: Upload files to GitHub and deploy via Vercel  
**RESULT**: Your new website will be live at https://www.britanniaforge.co.uk  
**TIME**: 5-10 minutes for complete deployment  

The platform is fully prepared for deployment. Once you upload to GitHub and deploy via Vercel, your new intelligent boiler quotation system will replace the current website and be fully functional.