// Test Enhanced Intelligence System
// Tests the improved genius boiler type selection logic

const scenarios = [
  {
    name: "4-bed, 3-bath House (Problem Scenario)",
    input: {
      bedrooms: "4",
      bathrooms: "3",
      occupants: "4",
      propertyType: "House",
      currentBoiler: "existing",
      postcode: "SW1A 1AA"
    },
    expected: {
      boilerType: "System",
      reasoning: "3+ bathrooms require system boiler"
    }
  },
  {
    name: "2-bed, 1-bath House (Combi Suitable)",
    input: {
      bedrooms: "2",
      bathrooms: "1",
      occupants: "2",
      propertyType: "House",
      currentBoiler: "combi",
      postcode: "SW1A 1AA"
    },
    expected: {
      boilerType: "Combi",
      reasoning: "Single bathroom property"
    }
  },
  {
    name: "3-bed, 2-bath House High Occupancy",
    input: {
      bedrooms: "3",
      bathrooms: "2",
      occupants: "4",
      propertyType: "House",
      currentBoiler: "system",
      postcode: "SW1A 1AA"
    },
    expected: {
      boilerType: "System",
      reasoning: "2 bathrooms with high simultaneous usage"
    }
  },
  {
    name: "1-bed, 1-bath Flat (Combi Ideal)",
    input: {
      bedrooms: "1",
      bathrooms: "1",
      occupants: "2",
      propertyType: "Flat",
      currentBoiler: "old",
      postcode: "SW1A 1AA"
    },
    expected: {
      boilerType: "Combi",
      reasoning: "Single bathroom property"
    }
  },
  {
    name: "5-bed, 3-bath Large House",
    input: {
      bedrooms: "5",
      bathrooms: "3",
      occupants: "6",
      propertyType: "House",
      currentBoiler: "regular",
      postcode: "SW1A 1AA"
    },
    expected: {
      boilerType: "System",
      reasoning: "3+ bathrooms"
    }
  }
];

console.log("🧪 ENHANCED INTELLIGENCE SYSTEM TEST");
console.log("====================================");

async function runTest(scenario) {
  console.log(`\n📋 Testing: ${scenario.name}`);
  console.log(`Input: ${JSON.stringify(scenario.input, null, 2)}`);
  
  try {
    const response = await fetch('http://localhost:5000/api/quote/calculate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(scenario.input)
    });
    
    const result = await response.json();
    
    console.log(`✅ Boiler Type: ${result.analysis.recommendedBoilerType}`);
    console.log(`✅ Boiler Size: ${result.analysis.recommendedBoilerSize}kW`);
    
    if (result.analysis.cylinderCapacity) {
      console.log(`✅ Cylinder: ${result.analysis.cylinderCapacity}L`);
    }
    
    // Check if result matches expected
    const passed = result.analysis.recommendedBoilerType === scenario.expected.boilerType;
    console.log(`${passed ? '✅ PASS' : '❌ FAIL'}: Expected ${scenario.expected.boilerType}, got ${result.analysis.recommendedBoilerType}`);
    
    return passed;
    
  } catch (error) {
    console.log(`❌ ERROR: ${error.message}`);
    return false;
  }
}

async function runAllTests() {
  const results = [];
  
  for (const scenario of scenarios) {
    const passed = await runTest(scenario);
    results.push({ name: scenario.name, passed });
    
    // Small delay between tests
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  
  console.log("\n📊 TEST RESULTS SUMMARY");
  console.log("=======================");
  
  results.forEach(result => {
    console.log(`${result.passed ? '✅' : '❌'} ${result.name}`);
  });
  
  const passedCount = results.filter(r => r.passed).length;
  const totalCount = results.length;
  
  console.log(`\n🎯 Overall: ${passedCount}/${totalCount} tests passed`);
  
  if (passedCount === totalCount) {
    console.log("🎉 ALL TESTS PASSED - Intelligence system is working correctly!");
  } else {
    console.log("⚠️  Some tests failed - System needs adjustment");
  }
}

// Run the tests
runAllTests().catch(console.error);