# 🚀 Vercel Deployment Guide - britanniaforge.co.uk

## 📋 Current Status
✅ **Domain**: britanniaforge.co.uk  
✅ **Hosting**: Vercel (DNS: ns1.vercel-dns.com, ns2.vercel-dns.com)  
✅ **IP Addresses**: 64.29.17.65, 216.198.79.1  
✅ **Deployment Files**: Ready for production deployment  

## 🎯 Deployment Strategy

Since your domain is already on Vercel, we'll deploy directly to your existing Vercel account, which will automatically replace your current website.

## 📦 Pre-Deployment Checklist

### 1. Required Files (✅ Ready)
- [x] `vercel.json` - Vercel configuration
- [x] `package.json` - Dependencies and scripts
- [x] `server/index.ts` - Express server
- [x] `client/` - React frontend
- [x] `.env.example` - Environment template
- [x] Database schema and migrations

### 2. Environment Variables Required
You'll need to set these in your Vercel dashboard:

```env
# Database Configuration
DATABASE_URL=postgresql://username:password@host:5432/britannia_forge

# JWT Secret for Authentication
JWT_SECRET=your_super_secret_jwt_key_here

# Stripe Payment Configuration
STRIPE_SECRET_KEY=sk_live_your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable_key

# Email Service Configuration
EMAIL_USER=your_email@domain.com
EMAIL_PASS=your_email_password

# Frontend Configuration
FRONTEND_URL=https://www.britanniaforge.co.uk
NODE_ENV=production
```

## 🚀 Step-by-Step Deployment

### Step 1: Push to GitHub Repository
```bash
# From your local machine or server
git clone https://github.com/BRITANNIAFORGELTD/britannia-forge-website.git
cd britannia-forge-website

# Copy all files from this Replit to your local repository
# Then push to GitHub
git add .
git commit -m "Complete Britannia Forge platform deployment"
git push origin main
```

### Step 2: Connect to Vercel
1. **Login to Vercel Dashboard**: https://vercel.com/dashboard
2. **Import Git Repository**: Click "Add New" → "Project"
3. **Connect GitHub**: Authorize Vercel to access your GitHub
4. **Select Repository**: Choose `BRITANNIAFORGELTD/britannia-forge-website`
5. **Configure Project**: 
   - Framework Preset: "Other"
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

### Step 3: Set Environment Variables
In Vercel Dashboard → Project → Settings → Environment Variables:

```env
DATABASE_URL=postgresql://your_db_connection_string
JWT_SECRET=your_jwt_secret_key
STRIPE_SECRET_KEY=sk_live_your_stripe_key
STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable
EMAIL_USER=your_email@domain.com
EMAIL_PASS=your_email_password
FRONTEND_URL=https://www.britanniaforge.co.uk
NODE_ENV=production
```

### Step 4: Deploy
1. **Click "Deploy"** in Vercel dashboard
2. **Wait for Build**: Monitor build logs for any errors
3. **Domain Configuration**: Ensure britanniaforge.co.uk is set as custom domain
4. **SSL Certificate**: Vercel automatically handles SSL

### Step 5: Database Setup
After deployment, you'll need to set up your database:

```bash
# If using Neon Database (recommended for Vercel)
# 1. Create account at https://neon.tech
# 2. Create database named "britannia_forge"
# 3. Copy connection string to DATABASE_URL

# Run database migrations
npx drizzle-kit push

# Create admin user
npx tsx server/create-admin.ts
```

## 🔧 Alternative: One-Click Deployment

### Option A: Deploy Button (Recommended)
1. **Add Deploy Button** to your GitHub README:
```markdown
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2FBRITANNIAFORGELTD%2Fbritannia-forge-website)
```

### Option B: Vercel CLI
```bash
# Install Vercel CLI
npm install -g vercel

# Login to Vercel
vercel login

# Deploy from repository
vercel --prod
```

## 📊 Post-Deployment Verification

### 1. Test Core Functionality
- [ ] **Homepage**: https://www.britanniaforge.co.uk
- [ ] **Quote System**: https://www.britanniaforge.co.uk/quote
- [ ] **Admin Login**: https://www.britanniaforge.co.uk/britannia1074/admin/login
- [ ] **Health Check**: https://www.britanniaforge.co.uk/health

### 2. Database Verification
```bash
# Test database connection
curl -X POST https://www.britanniaforge.co.uk/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"britanniaforge@gmail.com","password":"AdminSecure2025!"}'
```

### 3. Payment Integration
- [ ] Test Stripe payment flow
- [ ] Verify webhook endpoints
- [ ] Check transaction processing

## 🐛 Troubleshooting

### Common Vercel Deployment Issues

1. **Build Failures**
   ```bash
   # Check build logs in Vercel dashboard
   # Common issue: Missing dependencies
   npm install --save-dev @types/node
   ```

2. **Database Connection**
   ```bash
   # Verify DATABASE_URL format
   postgresql://username:password@host:port/database
   ```

3. **Environment Variables**
   ```bash
   # Ensure all variables are set in Vercel dashboard
   # Check spelling and formatting
   ```

4. **Function Timeout**
   ```json
   // In vercel.json
   "functions": {
     "server/index.ts": {
       "maxDuration": 30
     }
   }
   ```

## 🚨 Critical Configuration

### Database Provider Recommendation
For optimal Vercel performance, use **Neon Database**:
- **Serverless PostgreSQL**
- **Automatic scaling**
- **Built for edge functions**
- **Free tier available**

### Setup Neon Database:
1. Go to https://neon.tech
2. Create new project: "britannia-forge"
3. Copy connection string
4. Set as DATABASE_URL in Vercel

### SSL and Security
- ✅ **SSL Certificate**: Automatic with Vercel
- ✅ **HTTPS Redirect**: Automatic
- ✅ **Security Headers**: Configured in nginx.conf
- ✅ **Environment Protection**: Vercel encrypted storage

## 📈 Performance Optimization

### 1. Edge Functions
```json
// vercel.json
{
  "regions": ["lhr1"],
  "functions": {
    "server/index.ts": {
      "maxDuration": 30
    }
  }
}
```

### 2. Static Asset Optimization
- **Automatic compression**
- **CDN delivery**
- **Image optimization**
- **Caching headers**

### 3. Database Connection Pooling
```typescript
// Use connection pooling for better performance
import { Pool } from 'pg';
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});
```

## 🎉 Success Metrics

### Expected Performance
- **Cold Start**: < 1 second
- **Response Time**: < 200ms
- **Build Time**: < 2 minutes
- **Uptime**: 99.9%

### Business Metrics
- **Quote Conversion**: Track through analytics
- **User Engagement**: Monitor with Vercel Analytics
- **Error Rate**: < 0.1%
- **Customer Satisfaction**: Review system feedback

## 📞 Support Resources

### Vercel Support
- **Dashboard**: https://vercel.com/dashboard
- **Documentation**: https://vercel.com/docs
- **Community**: https://github.com/vercel/vercel/discussions

### Project Support
- **GitHub Issues**: https://github.com/BRITANNIAFORGELTD/britannia-forge-website/issues
- **Email**: britanniaforge@gmail.com
- **Admin Access**: britanniaforge@gmail.com / AdminSecure2025!

---

**Status**: ✅ READY FOR IMMEDIATE DEPLOYMENT  
**Expected Deployment Time**: 5-10 minutes  
**Domain**: https://www.britanniaforge.co.uk  
**Last Updated**: January 16, 2025  

The platform is configured for seamless Vercel deployment. Once deployed, your new intelligent boiler quotation system will be live at https://www.britanniaforge.co.uk, replacing the current website with full functionality.